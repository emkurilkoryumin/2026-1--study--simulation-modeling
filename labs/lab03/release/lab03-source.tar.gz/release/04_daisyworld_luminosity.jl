using DrWatson
@quickactivate "project"
using Agents
using DataFrames
using CairoMakie
include(srcdir("daisyworld.jl"))


black(a) = a.breed == :black
white(a) = a.breed == :white
adata = [(black, count), (white, count)]

global_temperature(model) = mean(model.temperature)
mdata = [:solar_luminosity, global_temperature]


model = daisyworld(; scenario=:ramp, solar_change=0.005)
agent_df, model_df = run!(model, 1000; adata, mdata)


fig = Figure(size=(800, 900))

ax1 = Axis(fig[1, 1]; ylabel="Численность")
lines!(ax1, agent_df.time, agent_df.count_black; color=:black, label="Чёрные")
lines!(ax1, agent_df.time, agent_df.count_white; color=:orange, label="Белые")
axislegend(ax1; position=:rt)


ax2 = Axis(fig[2, 1]; ylabel="Температура, °C")
lines!(ax2, model_df.time, model_df.temperature; color=:red, linewidth=2)


ax3 = Axis(fig[3, 1]; xlabel="Время (шаги)", ylabel="Светимость")
lines!(ax3, model_df.time, model_df.solar_luminosity; color=:blue, linewidth=2)


for ax in (ax1, ax2)
    ax.xticklabelsvisible = false
    ax.xlabelvisible = false
end

save(plotsdir("daisyworld_luminosity.png"), fig)
println("График сохранён: plots/daisyworld_luminosity.png")
